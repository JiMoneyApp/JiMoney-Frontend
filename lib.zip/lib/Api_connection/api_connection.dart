class API
{
  static const hostConnect = "";
}