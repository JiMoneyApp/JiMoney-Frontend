import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:jimoney_frontend/Register/presentation/login_page.dart';

Future<void> addData() async {
  final String baseUrl = 'http://54.179.125.22:5000/data/insert_new_data';
  final int userid = uid;
  

}