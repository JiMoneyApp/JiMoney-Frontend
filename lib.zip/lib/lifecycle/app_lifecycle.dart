// import 'package:go_router/go_router.dart';
// import 'package:jimoney_frontend/routing/auth_routes.dart';

// abstract interface class AppLifeCycle {
//   GoRouter getRouter();
// }

// class AppLifeCycleImpl implements AppLifeCycle {
//   late GoRouter _router;
//   AppLifeCycleImpl(this._router) {
//     _router = _createRouter();
//   }
//   GoRouter getRouter() {
//     return _router;
//   }
// }

// GoRouter _createRouter() {
//   return GoRouter(
//     debugLogDiagnostics: true,
//     initialLocation: "/loginafterlogout",
//     routes: authroutes,
//   );
// }
