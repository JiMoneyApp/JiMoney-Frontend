import 'package:flutter/cupertino.dart';

class ColumnChart extends StatefulWidget {
  const ColumnChart({super.key});

  @override
  State<ColumnChart> createState() => _ColumnChartState();
}

class _ColumnChartState extends State<ColumnChart> {
  

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}