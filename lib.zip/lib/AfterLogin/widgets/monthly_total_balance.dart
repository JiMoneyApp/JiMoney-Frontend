import 'package:flutter/cupertino.dart';

class MonthlyTotalBalance extends StatelessWidget {
  const MonthlyTotalBalance({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 600,
      alignment: Alignment.topCenter,
      child: Text(
        "AAA"
      ),
    );
  }
}